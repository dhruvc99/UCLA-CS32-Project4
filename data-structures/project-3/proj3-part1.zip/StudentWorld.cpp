#include "StudentWorld.h"
#include "GameConstants.h"
#include "Level.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

//

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath), m_Penelope(nullptr), m_numActors(0)
{}

StudentWorld::~StudentWorld()
{
    cleanUp();
}

int StudentWorld::init()
{
    m_Penelope = nullptr;
    
    Level level(assetPath());
    string levelFile = "level01.txt";
    Level::LoadResult loadResult = level.loadLevel(levelFile);
    
    if (loadResult == Level::load_fail_file_not_found)
        cerr << "Cannot find level01.txt data file" << endl;
    else if (loadResult == Level::load_fail_bad_format)
        cerr << "Your level was improperly formatted" << endl;
    else if (loadResult == Level::load_success)
    {
        cerr << "Successfully loaded level" << endl;
        
        for (int y = 0; y < LEVEL_HEIGHT; y++)
        {
            for (int x = 0; x < LEVEL_WIDTH; x++)
            {
                Level::MazeEntry ge = level.getContentsOf(x, y);
                
                if (ge == Level::player)
                    m_Penelope = new Penelope(SPRITE_WIDTH * x, SPRITE_HEIGHT * y, this);
                else if (ge == Level::wall)
                {
                    Actor* wallPtr = new Wall(SPRITE_WIDTH * x, SPRITE_HEIGHT * y, this);
                    m_Actors.push_back(wallPtr);
                    m_numActors++;
                }
            }
        }
    }
    else
        return GWSTATUS_LEVEL_ERROR;
    
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    m_Penelope->doSomething();
    
    list<Actor*>::iterator it = m_Actors.begin(); // don't need for part 1
    while (it != m_Actors.end())
    {
        (*it)->doSomething();
        it++;
    }
    
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    if (m_Penelope != nullptr)
        delete m_Penelope;

    list<Actor*>::iterator it = m_Actors.begin();
    while (it != m_Actors.end())
    {
        delete(*it);
        it = m_Actors.erase(it);
        it++;
    }
}

bool StudentWorld::checkMove(double x, double y, Actor* actor)
{
    list<Actor*>::iterator it = m_Actors.begin();
    
    while (it != m_Actors.end())
    {
        double actor_x = (*it)->getX();
        double actor_xmax = actor_x + SPRITE_WIDTH - 1;
        double actor_y = (*it)->getY();
        double actor_ymax = actor_y + SPRITE_HEIGHT - 1;
        
        if ((x >= actor_x && x <= actor_xmax) && (y >= actor_y && y <= actor_ymax))
            return false;
        if (((x + SPRITE_WIDTH - 1) >= actor_x && (x + SPRITE_WIDTH - 1) <= actor_xmax) && (y >= actor_y && y <= actor_ymax))
            return false;
        if ((x >= actor_x && x <= actor_xmax) && ((y + SPRITE_HEIGHT - 1) >= actor_y && (y + SPRITE_HEIGHT - 1) <= actor_ymax))
            return false;
        if (((x + SPRITE_WIDTH - 1) >= actor_x && (x + SPRITE_WIDTH - 1) <= actor_xmax) &&
            ((y + SPRITE_HEIGHT - 1) >= actor_y && (y + SPRITE_HEIGHT - 1) <= actor_ymax))
            return false;
        
        it++;
    }
    
    return true;
}
