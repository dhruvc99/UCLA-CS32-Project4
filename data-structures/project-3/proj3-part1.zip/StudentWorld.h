#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Actor.h"
#include <string>
#include <list>
using namespace std;

class StudentWorld: public GameWorld
{
public:
    StudentWorld(string assetPath);
    virtual ~StudentWorld();
    
    virtual int init();
    virtual int move();
    virtual void cleanUp();
    
    bool checkMove(double x, double y, Actor* actor);
    
private:
    list<Actor*> m_Actors;
    Penelope* m_Penelope;
    int m_numActors; // don't need for part 1
};

#endif // STUDENTWORLD_H_
