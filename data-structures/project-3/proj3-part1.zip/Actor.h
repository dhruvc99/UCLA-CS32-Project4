#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
using namespace std;

class StudentWorld;

// Actor class:

class Actor: public GraphObject
{
public:
    Actor(int imageID, double startX, double startY, int startDirection, int depth, StudentWorld* myWorld, string actorType);
    virtual void doSomething() = 0;
    const int STEP = 4;
    
    StudentWorld* getWorld() const
    {
        return m_World;
    }
    
    string getType() const
    {
        return m_actorType;
    }
    
private:
    StudentWorld* m_World;
    string m_actorType;
};

// Penelope class:

class Penelope: public Actor
{
public:
    Penelope(double startX, double startY, StudentWorld* myWorld);
    virtual void doSomething();
};

// Wall class:

class Wall: public Actor
{
public:
    Wall(double startX, double startY, StudentWorld* myWorld);
    virtual void doSomething();
};

#endif // ACTOR_H_
